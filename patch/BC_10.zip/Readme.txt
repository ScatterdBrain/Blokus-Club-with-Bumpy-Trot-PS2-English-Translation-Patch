An English translation patch for Irem's PS2 game Blokus Club with Bumpy Trot.

All of the text and textures (except logos) were machine translated and edited by me (ScatterBrain).

Patch file was created with Delta Patcher 3.1.5 and was tested with MD5: 37f2d3ecbbd4b15cc1af52379a99b66d copy of the game.

Don't forget to make a backup of your game before patching!

Special thanks to Luigi Auriemma from https://aluigi.altervista.org/ for making QuickBMS program and disaster_report.bms script.

If you have issues or want to retranslate the game you can reach out to me at https://www.romhacking.net forums.

!Advert!
I'm also looking for help with translation of another Irem's game PachiPara 12. If you know Japanese and want to help (or know someone who are) you can check out amount of text that needs to be translated here https://github.com/ScatterdBrain/PachiPara-12-English-Translation and contact me at romhacking.net